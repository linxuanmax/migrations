# __init__.py --- short description

# Copyright  (C)  2013  fallmoon <zhuwt@guohe.org>

# Version: 1.0
# Keywords:
# Author: fallmoon <zhuwt@guohe.org>
# Maintainer: fallmoon <zhuwt@guohe.org>
# URL: http://www.guohe.org

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# Codee:

VERSION = (1, 0, 0)
__version__ = ".".join(map(str, VERSION))
__author__ = "fallmoon"
__contact__ = "zhuwt@guohe.org"
__homepage__ = "http://www.guohe.org"
__docformat__ = "restructuredtext"
