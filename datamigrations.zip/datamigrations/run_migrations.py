#!usr/bin/env python
# coding=utf-8

from datamigrations import datamigrations


def main():
    datamigrations.run()

if __name__ == "__main__":
    main()
